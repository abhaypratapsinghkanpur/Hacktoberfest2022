# Gmail Automation
## [1. Sending mail](https://github.com/Aishanipach/Beginners-Python-Programs/blob/main/Gmail%20automation/mailswithpy.py)
   <img src="https://github.com/Aishanipach/Beginners-Python-Programs/blob/main/Gmail%20automation/input_mail.PNG"  width="300" height="100" /> <br><br>
   <img src="https://github.com/Aishanipach/Beginners-Python-Programs/blob/main/Gmail%20automation/my_first_mail.PNG" width= "400" height=" 250"/>

## [2. Receiving mail](https://github.com/Aishanipach/Beginners-Python-Programs/tree/main/Gmail%20automation)
   <img src="https://github.com/Aishanipach/Beginners-Python-Programs/blob/main/Gmail%20automation/received_mail.PNG"  width="300" height="100" /> <br><br>

---
### `smtplib` `getpass`
